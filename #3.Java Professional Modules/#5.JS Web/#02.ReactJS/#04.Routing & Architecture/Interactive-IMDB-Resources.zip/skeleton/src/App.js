import React, { Component } from 'react';
import Home from './Home/Home';
import Register from './Register/Register';
import Login from './Login/Login';
import Create from './Create/Create';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
         { /* TODO */ }
      </div>
    );
  }
}

export default App;
