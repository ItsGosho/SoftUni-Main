import React, { Component } from 'react';
import './Create.css';

class Create extends Component {
  render() {
    return (
      <div className="Create">
         {/* TODO */}
      </div>
    );
  }
}

export default Create;
