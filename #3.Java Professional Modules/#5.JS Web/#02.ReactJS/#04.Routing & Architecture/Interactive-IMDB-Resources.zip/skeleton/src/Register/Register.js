import React, { Component } from 'react';
import './Register.css';

class Register extends Component {
  render() {
    return (
      <div className="Register">
          { /* TODO */ }
      </div>
    );
  }
}

export default Register;
