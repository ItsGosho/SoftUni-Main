import React, { Component } from 'react';
import './Login.css';

class Login extends Component {
  render() {
    return (
      <div className="Login">
          { /* TODO */ }
      </div>
    );
  }
}

export default Login;
