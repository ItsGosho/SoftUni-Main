package T03T04_Barracks.contracts;

public interface Attacker {
    
    int getAttackDamage();
}
