package T03T04_Barracks.contracts;

public interface Unit extends Destroyable, Attacker {
}
