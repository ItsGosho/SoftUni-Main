package T03T04_Barracks.contracts;

public interface Executable {

	String execute();

}
