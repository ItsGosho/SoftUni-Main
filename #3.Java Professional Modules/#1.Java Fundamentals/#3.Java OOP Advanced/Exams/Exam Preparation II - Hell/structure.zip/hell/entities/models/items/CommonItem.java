package hell.entities.models.items;

public class CommonItem extends ItemImp {
    CommonItem(String name, int strengthBonus, int agilityBonus, int hitPointsBonus, int damageBonus) {
        super(name, strengthBonus, agilityBonus, hitPointsBonus, damageBonus);
    }
}
