package hell.entities.models.heroes;

public class Wizard extends HeroImp {
    Wizard(String name, int strength, int agility, int intelligence, int hitPoints, int damage) {
        super(name, strength, agility, intelligence, hitPoints, damage);
    }
}
