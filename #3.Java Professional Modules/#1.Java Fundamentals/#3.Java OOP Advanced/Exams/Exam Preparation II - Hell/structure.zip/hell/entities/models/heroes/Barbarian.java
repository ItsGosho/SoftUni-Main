package hell.entities.models.heroes;

public class Barbarian extends HeroImp {
    public Barbarian(String name, int strength, int agility, int intelligence, int hitPoints, int damage) {
        super(name, strength, agility, intelligence, hitPoints, damage);
    }
}
