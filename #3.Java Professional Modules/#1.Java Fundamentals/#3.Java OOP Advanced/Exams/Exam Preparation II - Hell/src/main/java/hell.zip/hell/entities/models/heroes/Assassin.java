package hell.entities.models.heroes;

public class Assassin extends HeroImp {
    public Assassin(String name, int strength, int agility, int intelligence, int hitPoints, int damage) {
        super(name, strength, agility, intelligence, hitPoints, damage);
    }
}
