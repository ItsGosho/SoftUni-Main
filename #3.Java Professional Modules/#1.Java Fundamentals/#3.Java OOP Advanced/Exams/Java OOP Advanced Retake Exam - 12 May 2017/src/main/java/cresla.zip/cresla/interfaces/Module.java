package cresla.interfaces;

public interface Module extends Identifiable {

    void removeFirst();
}
