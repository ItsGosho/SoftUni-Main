package callofduty.manager;

import callofduty.interfaces.MissionManager;

import java.util.List;

public class MissionManagerImp implements MissionManager {
    @Override
    public String agent(List<String> arguments) {
        return null;
    }

    @Override
    public String request(List<String> arguments) {
        return null;
    }

    @Override
    public String complete(List<String> arguments) {
        return null;
    }

    @Override
    public String status(List<String> arguments) {
        return null;
    }

    @Override
    public String over(List<String> arguments) {
        return null;
    }
}
