package callofduty.models.agents;

public class NoviceAgent extends AgentImp {

    public NoviceAgent(String id, String name) {
        super(id, name, 0);
    }
}
