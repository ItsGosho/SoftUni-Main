package callofduty.models.agents;

import callofduty.interfaces.BountyAgent;

public class MasterAgent extends AgentImp implements BountyAgent {

    private double bounty;


    public MasterAgent(String id, String name, double rating) {
        super(id, name, rating);
        this.bounty=0;
    }

    @Override
    public Double getBounty() {
        return null;
    }
}
