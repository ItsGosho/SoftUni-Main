package callofduty.models.agents;

import callofduty.interfaces.Agent;
import callofduty.interfaces.BountyAgent;
import callofduty.interfaces.Mission;

public abstract class AgentImp implements Agent {

    private String id;
    private String name;
    private double rating;

    AgentImp(String id, String name, double rating) {
        this.id = id;
        this.name = name;
        this.rating = rating;
    }


    @Override
    public void acceptMission(Mission mission) {

    }

    @Override
    public void completeMissions() {

    }

    @Override
    public String getId() {
        return null;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public Double getRating() {
        return null;
    }
}
