package callofduty.models.missions;

public class EscortMission extends MissionImp {

    public EscortMission(String id, double rating, double bounty) {
        super(id, rating-(rating*0.25), bounty*1.25);
    }
}
