package callofduty.models.missions;

public class HuntMission extends MissionImp {

    public HuntMission(String id, double rating, double bounty) {
        super(id, rating*1.50, bounty*2);
    }
}
