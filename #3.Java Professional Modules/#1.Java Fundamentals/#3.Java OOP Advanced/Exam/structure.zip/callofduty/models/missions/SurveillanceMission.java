package callofduty.models.missions;

public class SurveillanceMission extends MissionImp {


    public SurveillanceMission(String id, double rating, double bounty) {
        super(id, rating-(rating*0.75), bounty*1.50);
    }
}
