package callofduty.domain.agents;

import callofduty.domain.missions.MissionImp;
import callofduty.interfaces.Mission;

public class NoviceAgent extends AgentImp {

    public NoviceAgent(String id, String name) {
        super(id, name, 0);
    }

}
