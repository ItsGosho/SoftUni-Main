package entities.powers.interfaces;

public interface SuperPower {

    String getName();
    double getPowerPoints();
}
