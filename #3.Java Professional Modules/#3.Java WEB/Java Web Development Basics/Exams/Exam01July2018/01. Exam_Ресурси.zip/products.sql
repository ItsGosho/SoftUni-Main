INSERT INTO `products` (`id`,`description`,`name`,`price`,`type`) 
VALUES 
('19a12fff-5665-403d-bd68-8827a10e165b','A universal tool...','Injektoplqktor',1.56,'HEALTH'),
('2a9e4f97-11bc-4597-aa1f-62d91c789a18','Peking chushkas.','Chushkopek',500.23,'DOMESTIC'),
('2c270f23-8895-4fe8-b484-080e7d6fd5d8','Peking chushkas.','Chushkopek',500.23,'DOMESTIC'),
('2f097957-c3a6-46fc-ac13-9f0d08b3c2d8','A universal tool...','Injektoplqktor',1.56,'HEALTH'),
('4feb5a64-722f-48b7-aa11-2b7f8485a370','Peking chushkas.','Chushkopek',500.23,'DOMESTIC'),
('6dc82f9c-d13e-4d18-96f1-c742159221b0','A universal tool...','Injektoplqktor',1.56,'HEALTH'),
('735146fe-c581-42ac-872d-467a26f01351','Peking chushkas.','Chushkopek',500.23,'DOMESTIC'),
('a5fb34f3-e34f-4422-84bf-8205593e2fbd','Peking chushkas.','Chushkopek',500.23,'DOMESTIC'),
('c2534b5c-07b0-4d22-b8c7-bbe577fc8e07','A universal tool...','Injektoplqktor',1.56,'HEALTH'),
('fc00f718-0d78-4b01-a32d-9b6d7a04a6da','A universal tool...','Injektoplqktor',1.56,'HEALTH');
